% demo to extract rotated patch from image
% Tian Cao, University of North Carolina at Chapel Hill (tiancao@cs.unc.edu)


% rotate patch
close all
%clear all

I = imread('lena.png');    % gray image
%I = imread('peppers.png'); % color image
%figure, imshow(I)

center     = [200, 100]; % [x, y]
patchsize  = 61;         % odd number
angle      = 30;         % degree

%drawRectangleonImageAtAngle(I, center', patchsize, patchsize, angle);
rpatch = extractRotatedPatch(I, center, patchsize, patchsize, angle); 

figure, imshow(uint8(rpatch));

